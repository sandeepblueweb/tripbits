// Item Img
import img1 from '../../assets/img/common/biman_bangla.png'
import flightIcon from '../../assets/img/icon/right_arrow.png'
import flightIcon2 from '../../assets/img/icon/bg.png'



export const FlightData = [
    {
        id:1,
        img: img1,
        flightIcon:flightIcon,
        flightIcon2:flightIcon2,
        price:"$99.00",  
        from:"New York",
        fromAirport:"JFK - John F. Kennedy International...",
        to:"London",
        toAirport:"LCY, London city airport",
        desPrice:"$9,560",
        realPrice:"$7,560",
        offer:"*20% OFF",
    },
    {
        id:2,
        img: img1,
        flightIcon:flightIcon,
        flightIcon2:flightIcon2,
        price:"$99.00",  
        from:"New York",
        fromAirport:"JFK - John F. Kennedy International...",
        to:"London",
        toAirport:"LCY, London city airport",
        desPrice:"$9,560",
        realPrice:"$7,560",
        offer:"*20% OFF",
    },
    {
        id:3,
        img: img1,
        flightIcon:flightIcon,
        flightIcon2:flightIcon2,
        price:"$99.00",  
        from:"New York",
        fromAirport:"JFK - John F. Kennedy International...",
        to:"London",
        toAirport:"LCY, London city airport",
        desPrice:"$9,560",
        realPrice:"$7,560",
        offer:"*20% OFF",
    },
    {
        id:4,
        img: img1,
        flightIcon:flightIcon,
        flightIcon2:flightIcon2,
        price:"$99.00",  
        from:"New York",
        fromAirport:"JFK - John F. Kennedy International...",
        to:"London",
        toAirport:"LCY, London city airport",
        desPrice:"$9,560",
        realPrice:"$7,560",
        offer:"*20% OFF",
    },
]