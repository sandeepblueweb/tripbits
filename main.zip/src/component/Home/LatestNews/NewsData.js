import img1 from '../../../assets/img/news/small1.png'
import img2 from '../../../assets/img/news/small2.png'
import img3 from '../../../assets/img/news/small3.png'
import img4 from '../../../assets/img/news/small4.png'




export const NewsData = [
    {
        img: img1,
        heading: `Revolutionising the travel industry,
        one partnership at a time`,
        date:"26 Oct 2021",
        read:"5min read"
    },
  
    {
        img: img2,
        heading: `t is a long established fact that a reader will be
        distracted.`,
        date:"26 Oct 2021",
        read:"3min read"
    },
  
    {
        img: img3,
        heading: `There are many variations of passages of sum available`,
        date:"26 Oct 2021",
        read:"2min read"
    },
  
    {
        img: img4,
        heading: `Contrary to popular belief, Lorem Ipsum is not simply.`,
        date:"26 Oct 2021",
        read:"5min read"
    },

]