
import img1 from '../../../assets/img/imagination/imagination1.png'
import img2 from '../../../assets/img/imagination/imagination2.png'
import img3 from '../../../assets/img/imagination/imagination3.png'



export const DiscoverData = [
    {
        img: img1,
        heading: "7% Discount for all",
        span:"Airlines",
    },
    {
        img: img2,
        heading: "Travel around",
        span:"the world",
    },
    {
        img: img3,
        heading: "Luxury resorts",
        span:"top deals",
    },
]