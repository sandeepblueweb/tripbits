// Import NewItem Img
import Img1 from '../../assets/img/news/news-1.png'
import Img2 from '../../assets/img/news/news-2.png'
import Img3 from '../../assets/img/news/news-3.png'
import Img4 from '../../assets/img/news/news-4.png'
import Img5 from '../../assets/img/news/news-5.png'
import Img6 from '../../assets/img/news/news-6.png'

// Import NewItem Author Img
import Auth1 from "../../assets/img/news/author-1.png"
import Auth2 from "../../assets/img/news/author-2.png"
import Auth3 from "../../assets/img/news/author-3.png"
import Auth4 from "../../assets/img/news/author-4.png"
import Auth5 from "../../assets/img/news/author-5.png"
import Auth6 from "../../assets/img/news/author-6.png"


export const NewsData =  [


    {
        id:1,
        img: Img1,
        auth:Auth1,
        heading:`Revolutionising the travel industry,
        one partnership at a time`,
         para: `Irure enim eiusmod ipsum do Lorem sit consectetur enim consectetur. Nostrud ipsum
         eiusmod eiusmod culpa anim excepteur.`,
        name: "Jennifer lawrence",
        date: "26 Oct 2021",
        readTime:"8 min read"
    },
    {
        id:2,
        img: Img2,
        auth:Auth2,
        heading:`Revolutionising the travel industry,
        one partnership at a time`,
         para: `Irure enim eiusmod ipsum do Lorem sit consectetur enim consectetur. Nostrud ipsum
         eiusmod eiusmod culpa anim excepteur.`,
        name: "Jennifer lawrence",
        date: "26 Oct 2021",
        readTime:"8 min read"
    },
    {
        id:3,
        img: Img3,
        auth:Auth3,
        heading:`Revolutionising the travel industry,
        one partnership at a time`,
         para: `Irure enim eiusmod ipsum do Lorem sit consectetur enim consectetur. Nostrud ipsum
         eiusmod eiusmod culpa anim excepteur.`,
        name: "Jennifer lawrence",
        date: "26 Oct 2021",
        readTime:"8 min read"
    },
    {
        id:4,
        img: Img4,
        auth:Auth4,
        heading:`Revolutionising the travel industry,
        one partnership at a time`,
         para: `Irure enim eiusmod ipsum do Lorem sit consectetur enim consectetur. Nostrud ipsum
         eiusmod eiusmod culpa anim excepteur.`,
        name: "Jennifer lawrence",
        date: "26 Oct 2021",
        readTime:"8 min read"
    },
    {
        id:5,
        img: Img5,
        auth:Auth5,
        heading:`Revolutionising the travel industry,
        one partnership at a time`,
         para: `Irure enim eiusmod ipsum do Lorem sit consectetur enim consectetur. Nostrud ipsum
         eiusmod eiusmod culpa anim excepteur.`,
        name: "Jennifer lawrence",
        date: "26 Oct 2021",
        readTime:"8 min read"
    },
    {
        id:6,
        img: Img6,
        auth:Auth6,
        heading:`Revolutionising the travel industry,
        one partnership at a time`,
         para: `Irure enim eiusmod ipsum do Lorem sit consectetur enim consectetur. Nostrud ipsum
         eiusmod eiusmod culpa anim excepteur.`,
        name: "Jennifer lawrence",
        date: "26 Oct 2021",
        readTime:"8 min read"
    }
]